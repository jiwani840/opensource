# face-sunguk-test
협업용 레포지토리입니다.
license: 상업적 용도로 사용가능, 출저 안 밝혀도 됨.
단, https://www.youtube.com/channel/UCCsbBI8ngIxn8wTnjPG6AfA?view_as=subscriber
에 들어가 코딩하는 이 선생 유튜브를 구독해야합니다.
